P=(int(input('Digite el precio del producto ')))
I=P*0.19
T=P+I
print('El precio con iva de este producto es:',T)
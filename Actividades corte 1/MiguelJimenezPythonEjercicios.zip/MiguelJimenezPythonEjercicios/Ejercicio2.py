P=float(input('Digite la medida en pulgadas '))
R=P*25.4
print(P,'pulgadas a milimetros, serian',R, 'milimentros')
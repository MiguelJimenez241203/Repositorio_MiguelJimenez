F=(float(input('Digite la temperatura en F ')))
C=(((F-32)*5)/9)
print(F,'grados Farenheit son',C,'en grados Celsius')